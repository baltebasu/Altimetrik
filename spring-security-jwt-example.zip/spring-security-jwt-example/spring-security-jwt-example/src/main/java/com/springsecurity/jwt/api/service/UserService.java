package com.springsecurity.jwt.api.service;

import com.springsecurity.jwt.api.entity.Product;
import com.springsecurity.jwt.api.entity.User;
import com.springsecurity.jwt.api.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.stream.IntStream;

@Service
public class UserService {

    @Autowired
    private UserRepository repository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    public String addUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        repository.save(user);
        return "user added in to the DB ";
    }

    public List<User> getAllusers() {
        return repository.findAll();
    }




}
