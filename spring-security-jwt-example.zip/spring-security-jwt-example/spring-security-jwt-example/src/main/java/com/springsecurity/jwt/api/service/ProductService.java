package com.springsecurity.jwt.api.service;

import com.springsecurity.jwt.api.entity.Product;
import com.springsecurity.jwt.api.entity.User;
import com.springsecurity.jwt.api.repository.ProductRepository;
import com.springsecurity.jwt.api.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository repository;

    List<Product> productList = null;

    public String addProduct(Product product) {
        repository.save(product);
        return "product added in to the DB ";
    }

    public List<Product> getProducts() {
        return repository.findAll();
    }

    public Product getProduct(int id) {
        Product product = repository.findByProductId(id);
        return product;
    }

}
