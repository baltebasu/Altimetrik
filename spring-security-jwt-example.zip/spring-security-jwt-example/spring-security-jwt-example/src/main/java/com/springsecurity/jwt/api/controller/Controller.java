package com.springsecurity.jwt.api.controller;

import com.springsecurity.jwt.api.entity.AuthRequest;
import com.springsecurity.jwt.api.entity.Product;
import com.springsecurity.jwt.api.entity.User;
import com.springsecurity.jwt.api.service.ProductService;
import com.springsecurity.jwt.api.service.UserService;
import com.springsecurity.jwt.api.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
public class Controller {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserService service;

    @Autowired
    private ProductService productService;

    @GetMapping("/welcome")
    public String welcome() {
        return "welcome";
    }

    @PostMapping("/login")
    public String generateToken(@RequestBody AuthRequest authRequest) throws Exception {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authRequest.getUserNmae(), authRequest.getPassword()));
        } catch (Exception e) {
            throw new Exception("user is not found");
        }
        String username = null;
        return jwtUtil.generateToken(authRequest.getUserNmae());
    }

    @PostMapping("/new")
    @PreAuthorize("hasAuthority('Admin')")
    public String addNewUser(@RequestBody User user) {
        return service.addUser(user);
    }

    @PostMapping("/addProduct")
    @PreAuthorize("hasAuthority('Admin')")
    public String addProduct(@RequestBody Product product) {
        return productService.addProduct(product);
    }

    @GetMapping("/allUsers")
//  @PreAuthorize("hasAuthority('Admin') or hasAuthority('User')")
    public List<User> getAllUsers() {
        List<User> allUsers = service.getAllusers();
        return allUsers;
    }

    @GetMapping("/all")
//  @PreAuthorize("hasAuthority('Admin') or hasAuthority('User')")
    public List<Product> getAllProducts() {
        return productService.getProducts();
    }

    @GetMapping("/product/{id}")
    @PreAuthorize("hasAuthority('User')")
    public Product getProductById(@PathVariable int id) {
        return productService.getProduct(id);
    }
}





/*private List<String> getRolesByLoggedInUser(Principal principal) {
        String roles = getLoggedInUser(principal).getRoles();
        List<String> assignRoles = Arrays.stream(roles.split(",")).collect(Collectors.toList());
        if (assignRoles.contains("Admin")) {
            return Arrays.stream(admin).collect(Collectors.toList());
        }
        if (assignRoles.contains("User")) {
            return Arrays.stream(user).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }
    private User getLoggedInUser(Principal principal) {
        return repository.findByUserName(principal.getName()).get();
    }*/

