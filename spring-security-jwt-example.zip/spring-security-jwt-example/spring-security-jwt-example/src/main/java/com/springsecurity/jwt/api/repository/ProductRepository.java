package com.springsecurity.jwt.api.repository;

import com.springsecurity.jwt.api.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product,Integer> {
    @Override
    public List<Product> findAll();
    Product findByProductId(int id);
}
