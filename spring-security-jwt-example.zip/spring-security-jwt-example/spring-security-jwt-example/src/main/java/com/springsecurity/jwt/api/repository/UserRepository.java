package com.springsecurity.jwt.api.repository;

import com.springsecurity.jwt.api.entity.Product;
import com.springsecurity.jwt.api.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    Optional<User> findByUserName(String username);

    @Override
    Optional<User> findById(Integer integer);

    public List<User> findAll();
}
